// service-worker.js

// Nama cache Anda
var cacheName = 'Rafik Rivaldi-pwa-v1';

// Daftar sumber daya yang ingin Anda cache
var filesToCache = [
  '/',
  '/index.html',
  '/manifest.json',
  '/images/icon.png',
  '/css/styles.css',
  '/service-worker.js',
];

// Instalasi Service Worker
self.addEventListener('install', evt => {
    evt.waitUntil(
        caches.open(cacheName).then(function(cache) {
            return cache.addAll(filesToCache);
        })
    );
});

// Aktivasi Service Worker
self.addEventListener('activate', evt => {

});

// Fetching sumber daya dari cache atau jaringan
// self.addEventListener('fetch', evt => {
//     evt.respondWith(
//         caches.match(evt.request).then(cacheRes => {
//             // Menggunakan sumber daya dari cache jika ada
//             return cacheRes || fetch(evt.request);
//         })
//     );
// });

self.addEventListener('fetch', function(event) {
    event.respondWith(
      fetch(event.request)
        .then(function(response) {
          // Data berhasil diambil dari jaringan, cache data tersebut
          if (response.status === 200) {
            const responseClone = response.clone();
            caches.open('my-cache').then(function(cache) {
              cache.put(event.request, responseClone);
            });
          }
          return response;
        })
        .catch(function() {
          // Jika gagal mengambil data dari jaringan, coba ambil dari cache
          return caches.match(event.request);
   })
  );
  });

  self.addEventListener('push', function(event) {
    if (self.Notification.permission === 'granted') {
      // Izin notifikasi telah diberikan, Anda dapat menampilkan pemberitahuan
      const options = {
        body: 'Apakah bapak mau memberi nilai "A" kepada saya??',
        icon: '/images/icon-192.png',
        actions: [
          { action: 'yes', title: 'YES' },
          { action: 'no', title: 'NOW' }
        ],
        data: {
          senderId: '12345',
          messageId: '67890'
        },
        silent: true,
        timestamp: Date.now()
      };
      
  
      event.waitUntil(
        self.registration.showNotification('Notifikasi', options)
      );
    } else {
      // Izin notifikasi tidak diberikan
    }
  });
  
  self.addEventListener('notificationclick', function(event) {
    event.notification.close();
  
    if (event.action === 'yes') {
      // Tindakan "Ya" diambil
      // Menampilkan notifikasi dengan ucapan "Anda memilih Ya"
      self.registration.showNotification('Terimakasih', {
        body: 'Terimakasih Bapak sudah baik, memberi nilai yang bagus kepada saya',
        icon: '/images/icon-256.png'
      });
    } else if (event.action === 'no') {
      // Tindakan "Tidak" diambil
      // Menampilkan notifikasi dengan ucapan "Anda memilih Tidak"
      self.registration.showNotification('Duhhh pak pak', {
        body: 'Gak Bahaya tah...',
        icon: '/images/icon-512.png'
      });
    } else {
      // Notifikasi di-klik tanpa memilih tindakan apa pun
      // Lakukan sesuatu ketika notifikasi di-klik tanpa memilih "Ya" atau "Tidak"
      console.log('Anda mengklik notifikasi');
    }
  });